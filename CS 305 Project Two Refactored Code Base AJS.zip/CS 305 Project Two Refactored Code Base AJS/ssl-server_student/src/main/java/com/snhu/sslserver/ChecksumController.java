package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** Provides a SHA-256 checksum for a fixed demonstration string. */
@RestController
public class ChecksumController {

    // Unique demonstration data required for the CS 305 Project Two evidence.
    private static final String DATA =
            "Hello Ashton Sells - Artemis Financial checksum verification 2026-10-12";

    @GetMapping(value = "/hash", produces = "text/html;charset=UTF-8")
    public String getChecksum() throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(DATA.getBytes(StandardCharsets.UTF_8));
        String checksum = bytesToHex(hash);

        return "<!doctype html><html><head><meta charset=\"UTF-8\"><title>Checksum Verification</title></head>"
                + "<body><h1>Artemis Financial Checksum Verification</h1>"
                + "<p><strong>Data:</strong> " + DATA + "</p>"
                + "<p><strong>SHA-256 checksum:</strong> <code>" + checksum + "</code></p>"
                + "<p>SHA-256 produces a 256-bit (64 hexadecimal character) digest.</p></body></html>";
    }

    /** Converts each byte to two lowercase hexadecimal characters. */
    static String bytesToHex(byte[] bytes) {
        StringBuilder hex = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            hex.append(String.format("%02x", value & 0xff));
        }
        return hex.toString();
    }
}
